package expense.api.msgs;

// a basic service response message.
public abstract class ResponseMsg {
}
